# TSD Technologies 1.5.0

Your tools. One terminal.

Personal Field Terminal and expandable Field OS for SPT 4.1.6. Purchase the tablet from Mechanic and install compatible apps separately.

## New in 1.5.0

- Arrow-key panning and mouse-wheel zoom while the minimap is enlarged; returning to compact restores player follow.
- Hides during inventory, corpse/container looting, raid loading and timer/extraction panels.
- Independent F12 toggles for the in-game clock and remaining raid time. The raid timer turns red at 10:00 or less.
- Lower-resolution performance mode preserves the enlarged viewing area and normal icon sizes. Disable it for sharper native-resolution drawing.

## Requirements and use

SPT 4.1.6 and Anvil WebOverlay 1.12.0 or newer. Satellite 1.0.1 is optional, installed separately for Maps. Messenger 1.0.0 and Logistics 3.1.0 remain separate compatible apps. Fika compatibility is unverified.

Extract into the main SPT game folder, merging BepInEx and SPT_Runtime. Keep existing configurations, wallpapers and separately installed apps when updating. See Upgrade-TsdTechnologies.md.

Fresh installations default to F9 for the tablet; existing key settings are preserved. M enlarges the minimap using the selected Hold or Toggle mode. Open interactive Maps through the tablet. Configure controls, boot frequency and Satellite minimap placement in F12. Change visible map content through Satellite’s own menu inside Maps.

## Credits

Thanks to maschine for Anvil WebOverlay and to Fums for Satellite. Satellite by Fums, CC BY-NC 4.0: https://sp-mod.com/mod/3373/satellite and https://github.com/MrFums/Satellite . The bridge adapts the viewer for the tablet. Satellite’s code and maps are not bundled.
