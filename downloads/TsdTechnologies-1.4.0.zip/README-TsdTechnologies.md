# TSD Technologies 1.4.0

Your tools. One terminal.

Personal Field Terminal and expandable Field OS for SPT 4.1.6. Purchase the tablet from Mechanic and install compatible apps separately.

## New in 1.4.0

- Satellite live maps inside the tablet, with an optional matching click-through minimap.
- Saved map preferences and shared visibility choices for the minimap.
- Configurable direct Maps shortcut (M by default).
- Once-per-game-launch boot by default, with an optional once-per-raid mode.

## Requirements and use

SPT 4.1.6 and Anvil WebOverlay 1.12.0 or newer. Satellite 1.0.1 is optional, installed separately for Maps. Messenger 1.0.0 and Logistics 3.1.0 remain separate compatible apps. Fika compatibility is unverified.

Extract into the main SPT game folder, merging BepInEx and SPT_Runtime. Keep existing configurations, wallpapers and separately installed apps when updating. See Upgrade-TsdTechnologies.md.

Fresh installations default to F9 for the tablet; existing key settings are preserved. M opens Maps directly. Configure controls, boot frequency and Satellite minimap placement in F12. Change visible map content through Satellite’s own menu inside Maps.

## Credits

Thanks to maschine for Anvil WebOverlay and to Fums for Satellite. Satellite by Fums, CC BY-NC 4.0: https://sp-mod.com/mod/3373/satellite and https://github.com/MrFums/Satellite . The bridge adapts the viewer for the tablet. Satellite’s code and maps are not bundled.
